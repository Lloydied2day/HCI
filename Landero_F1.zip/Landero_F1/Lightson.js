function turnOn() {
    document.getElementById('bulbImage').style.display = 'block'; 
    document.getElementById('offImage').style.display = 'none';  
}

function turnOff() {
    document.getElementById('bulbImage').style.display = 'none';  
    document.getElementById('offImage').style.display = 'block'; 
}
